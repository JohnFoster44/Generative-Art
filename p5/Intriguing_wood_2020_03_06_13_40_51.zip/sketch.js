
function setup() { 
  createCanvas(400, 400)
  background(255)
  
} 

function draw() {
  setInterval(ranSquare, 1000);
}

function ranSquare(){
  
    var count = 10
    var randomH = random(height)
    var randomW = random(width)
    
    randomStroke = stroke(random(10))
    randomCol = color(random(255),random(255),random(255))
    
  for(i = 0; i < count; i++){
    for(n = 0; n < count; n++){
      
      square(randomH, randomW, 55);
      strokeWeight(4);
      translate(randomH, randomW);
  
      stroke(randomCol)
    }  
    
    
}}

