var randomCol
var randomPos
var randomH
var randomW

function setup() {
  createCanvas(500, 500);
}

function draw() {
  randomCol = color(random(255),random(255),random(255));
  
  var randomH = random(height)
  var randomW = random(width)
    
  background(255)
  
  var count = 2;
  
  for(i = 0; i < count; i++){
    for(n = 0; n < count; n++){
      
      square(randomH, randomW, 55);
      strokeWeight(4);
      translate(randomH, randomW);
  
      stroke(randomCol);
    
    }  
}};

